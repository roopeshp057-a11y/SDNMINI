#!/usr/bin/env python3
"""
validate.py  ─  Automated Test & Regression Suite
===================================================
Tests the Traffic Classification System without needing
a running Mininet session.  Checks:
  1. Flow rule presence via ovs-ofctl
  2. Protocol classification accuracy (stats file)
  3. Block/allow enforcement
  4. REST API reachability (if rest_api loaded)
  5. Regression: stats only go up (no counter resets)

Run AFTER starting POX and Mininet:
  python3 tests/validate.py
  python3 tests/validate.py --switch s1 --verbose
"""

import argparse
import json
import os
import subprocess
import sys
import time

STATS_FILE    = os.path.join(os.path.dirname(__file__),
                              "..", "controller", "traffic_stats.json")
REST_BASE     = "http://127.0.0.1:8080"
PASS          = "\033[92m[PASS]\033[0m"
FAIL          = "\033[91m[FAIL]\033[0m"
SKIP          = "\033[93m[SKIP]\033[0m"
INFO          = "\033[94m[INFO]\033[0m"


# ── Helpers ───────────────────────────────────────────────────────────────────

def run(cmd: str, timeout: int = 15) -> tuple[int, str, str]:
    r = subprocess.run(cmd, shell=True, capture_output=True,
                       text=True, timeout=timeout)
    return r.returncode, r.stdout, r.stderr


def load_stats() -> dict | None:
    try:
        with open(STATS_FILE) as f:
            return json.load(f)
    except Exception:
        return None


def section(title: str):
    print(f"\n{'─'*60}")
    print(f"  {title}")
    print("─"*60)


# ── Test functions ────────────────────────────────────────────────────────────

def test_ovs_connected(switch: str) -> bool:
    """Check that OVS bridge is connected to the POX controller."""
    section("T1: OVS Controller Connection")
    rc, out, _ = run(f"sudo ovs-vsctl get-controller {switch}")
    connected  = rc == 0 and "6633" in out
    print(f"  Controller string: {out.strip()}")
    print(f"  {PASS if connected else FAIL} Switch {switch} connected to POX on port 6633")
    return connected


def test_flow_rules_installed(switch: str) -> bool:
    """Verify that classification flow rules are present in OVS."""
    section("T2: OpenFlow Rule Installation")
    rc, out, _ = run(f"sudo ovs-ofctl dump-flows {switch}")
    if rc != 0:
        print(f"  {FAIL} Could not dump flows from {switch}")
        return False

    checks = [
        ("ARP rule",     "arp"),
        ("IP/ICMP rule", "icmp"),
        ("IP/TCP rule",  "tcp"),
        ("IP/UDP rule",  "udp"),
        ("Table-miss",   "actions=CONTROLLER"),
    ]

    all_pass = True
    for label, pattern in checks:
        found = pattern in out
        print(f"  {PASS if found else FAIL} {label:<20} (pattern: '{pattern}')")
        all_pass = all_pass and found

    flow_count = out.count("actions=")
    print(f"\n  Total flow entries: {flow_count}")
    return all_pass


def test_stats_file_exists() -> bool:
    """Check that the controller is writing the stats JSON file."""
    section("T3: Stats File Output")
    exists = os.path.isfile(STATS_FILE)
    print(f"  Path: {STATS_FILE}")
    print(f"  {PASS if exists else FAIL} Stats file {'found' if exists else 'NOT FOUND'}")
    if not exists:
        print(f"  Hint: Start the POX controller first")
    return exists


def test_classification_accuracy() -> bool:
    """
    Verify that classified protocol counts are sane.
    All counters must be ≥ 0; known-generated traffic should be > 0.
    """
    section("T4: Classification Accuracy (Stats)")
    data = load_stats()
    if not data:
        print(f"  {SKIP} Stats file not available")
        return False

    all_pass  = True
    switches  = data.get("switches", {})
    if not switches:
        print(f"  {SKIP} No switches in stats yet")
        return False

    for dpid, proto_map in switches.items():
        print(f"\n  Switch {dpid}:")
        total_pkts = sum(v.get("packets", 0) for v in proto_map.values())
        for proto in ["TCP", "UDP", "ICMP", "ARP", "OTHER"]:
            s    = proto_map.get(proto, {})
            pkts = s.get("packets", 0)
            byt  = s.get("bytes", 0)
            ok   = pkts >= 0 and byt >= 0
            pct  = 100.0 * pkts / total_pkts if total_pkts else 0
            print(f"    {PASS if ok else FAIL} {proto:<6} "
                  f"pkts={pkts:,}  bytes={byt:,}  ({pct:.1f}%)")
            all_pass = all_pass and ok

    return all_pass


def test_block_enforcement() -> bool:
    """
    Validate block counters: if block_udp or block_icmp is True,
    the blocked counter for that protocol should be > 0 after traffic.
    """
    section("T5: Block Enforcement Validation")
    data = load_stats()
    if not data:
        print(f"  {SKIP} Stats file not available")
        return False

    cfg        = data.get("config", {})
    block_udp  = cfg.get("block_udp",  False)
    block_icmp = cfg.get("block_icmp", False)

    if not block_udp and not block_icmp:
        print(f"  {SKIP} No protocols blocked in current config")
        print(f"  Hint: launch with --block_udp=True or --block_icmp=True")
        return True   # not a failure; config is valid

    all_pass = True
    for dpid, proto_map in data.get("switches", {}).items():
        if block_udp:
            blk = proto_map.get("UDP", {}).get("blocked", 0)
            ok  = blk > 0
            print(f"  {PASS if ok else FAIL} UDP blocked={blk} on {dpid}")
            all_pass = all_pass and ok
        if block_icmp:
            blk = proto_map.get("ICMP", {}).get("blocked", 0)
            ok  = blk > 0
            print(f"  {PASS if ok else FAIL} ICMP blocked={blk} on {dpid}")
            all_pass = all_pass and ok

    return all_pass


def test_counter_regression() -> bool:
    """
    Regression test: read stats twice 5s apart;
    all packet/byte counters must be non-decreasing.
    """
    section("T6: Counter Regression (no resets)")
    snap1 = load_stats()
    if not snap1:
        print(f"  {SKIP} Stats not available")
        return False

    print("  Taking first snapshot...")
    time.sleep(5)
    snap2 = load_stats()
    if not snap2:
        print(f"  {SKIP} Second snapshot failed")
        return False

    all_pass = True
    for dpid in snap1.get("switches", {}):
        for proto in ["TCP", "UDP", "ICMP", "ARP", "OTHER"]:
            p1 = snap1["switches"].get(dpid, {}).get(proto, {}).get("packets", 0)
            p2 = snap2["switches"].get(dpid, {}).get(proto, {}).get("packets", 0)
            ok = p2 >= p1
            if not ok:
                print(f"  {FAIL} {proto} counter DECREASED: {p1} → {p2} on {dpid}")
                all_pass = False
            else:
                print(f"  {PASS} {proto:<6} {p1:,} → {p2:,}  (+{p2-p1:,})")

    return all_pass


def test_ping_reachability(src_ip="10.0.0.1", dst_ip="10.0.0.4") -> bool:
    """Quick ICMP reachability test using the host's ping (if h1 is accessible)."""
    section("T7: ICMP Reachability (from host)")
    print(f"  Pinging {dst_ip} from {src_ip}...")
    rc, out, _ = run(f"ping -c 3 -W 2 {dst_ip} 2>&1", timeout=10)
    success    = "0% packet loss" in out or "0 received" not in out
    for line in out.splitlines():
        if "packet loss" in line or "rtt" in line:
            print(f"  {line.strip()}")
    print(f"  {PASS if success else FAIL} ICMP ping {'succeeded' if success else 'FAILED'}")
    return success


def test_flow_count_sanity(switch: str) -> bool:
    """Ensure there are at least 5 flow entries (our proactive rules)."""
    section("T8: Flow Count Sanity")
    rc, out, _ = run(f"sudo ovs-ofctl dump-flows {switch}")
    count = out.count("actions=")
    ok    = count >= 5
    print(f"  Flow entries on {switch}: {count}")
    print(f"  {PASS if ok else FAIL} Expected ≥5 proactive rules, found {count}")
    return ok


# ── Report ────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Traffic Classifier Validation Suite")
    ap.add_argument("--switch",  default="s1",   help="OVS switch name (default: s1)")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    print("\n" + "═"*60)
    print("  TRAFFIC CLASSIFICATION SYSTEM – VALIDATION SUITE")
    print("═"*60)

    results = []

    tests = [
        ("OVS Controller Connection",  lambda: test_ovs_connected(args.switch)),
        ("Flow Rules Installed",        lambda: test_flow_rules_installed(args.switch)),
        ("Stats File Output",           lambda: test_stats_file_exists()),
        ("Classification Accuracy",     lambda: test_classification_accuracy()),
        ("Block Enforcement",           lambda: test_block_enforcement()),
        ("Counter Regression",          lambda: test_counter_regression()),
        ("ICMP Reachability",           lambda: test_ping_reachability()),
        ("Flow Count Sanity",           lambda: test_flow_count_sanity(args.switch)),
    ]

    for name, fn in tests:
        try:
            passed = fn()
            results.append((name, passed))
        except Exception as e:
            print(f"  {FAIL} {name} raised exception: {e}")
            results.append((name, False))

    # Summary
    print("\n" + "═"*60)
    print("  TEST SUMMARY")
    print("═"*60)
    passed_n = sum(1 for _, r in results if r)
    failed_n = len(results) - passed_n

    for name, r in results:
        icon = PASS if r else FAIL
        print(f"  {icon} {name}")

    print(f"\n  {passed_n}/{len(results)} tests passed  "
          f"({failed_n} failed)\n")

    sys.exit(0 if failed_n == 0 else 1)


if __name__ == "__main__":
    main()
