#!/usr/bin/env python3
"""
display_stats.py  ─  Real-Time Traffic Classification Results Viewer
=====================================================================
Reads the JSON stats file written by the POX controller and renders
a rich terminal dashboard with:
  • Per-protocol packet/byte counts
  • Traffic distribution bar chart (ASCII)
  • Block/allow summary
  • Flow installation counts

Run WHILE the POX controller is running:
  python3 tests/display_stats.py              # refresh every 3s
  python3 tests/display_stats.py --interval 5
  python3 tests/display_stats.py --once        # single snapshot
"""

import json
import os
import sys
import time
import argparse
from datetime import datetime

STATS_FILE = os.path.join(os.path.dirname(__file__),
                          "..", "controller", "traffic_stats.json")

# ── ANSI colours ─────────────────────────────────────────────────────────────
R  = "\033[91m"   # red
G  = "\033[92m"   # green
Y  = "\033[93m"   # yellow
B  = "\033[94m"   # blue
M  = "\033[95m"   # magenta
C  = "\033[96m"   # cyan
W  = "\033[97m"   # white
DIM= "\033[2m"
RST= "\033[0m"
BOLD="\033[1m"

PROTO_COLOURS = {
    "TCP":   B,
    "UDP":   G,
    "ICMP":  Y,
    "ARP":   M,
    "OTHER": DIM,
}

BAR_WIDTH = 30


def clear():
    os.system("clear" if os.name != "nt" else "cls")


def load_stats(path: str) -> dict | None:
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def bar(fraction: float, width: int = BAR_WIDTH, colour: str = G) -> str:
    filled = int(fraction * width)
    empty  = width - filled
    return colour + "█" * filled + DIM + "░" * empty + RST


def bytes_human(n: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def render(data: dict):
    ts      = datetime.fromtimestamp(data["timestamp"]).strftime("%H:%M:%S")
    uptime  = data.get("uptime_s", 0)
    hh, rem = divmod(uptime, 3600)
    mm, ss  = divmod(rem, 60)
    cfg     = data.get("config", {})

    sep = W + "─" * 72 + RST

    print(f"\n{BOLD}{W}{'SDN TRAFFIC CLASSIFICATION SYSTEM':^72}{RST}")
    print(f"{DIM}{'Last update: ' + ts + '   Uptime: ' + f'{hh:02d}:{mm:02d}:{ss:02d}':^72}{RST}")
    print(sep)

    # Config banner
    udp_status  = R + "BLOCKED" + RST if cfg.get("block_udp")  else G + "ALLOWED" + RST
    icmp_status = R + "BLOCKED" + RST if cfg.get("block_icmp") else G + "ALLOWED" + RST
    tcp_blocked = cfg.get("blocked_tcp_ports", [])
    udp_blocked = cfg.get("blocked_udp_ports", [])
    print(f"  UDP: {udp_status}   ICMP: {icmp_status}   "
          f"TCP blocked ports: {tcp_blocked or 'none'}   "
          f"UDP blocked ports: {udp_blocked or 'none'}")
    print(sep)

    switches = data.get("switches", {})
    if not switches:
        print(f"\n  {Y}Waiting for switch connections...{RST}\n")
        return

    for dpid, proto_map in switches.items():
        # Aggregate totals for this switch
        total_pkts  = sum(v["packets"] for v in proto_map.values())
        total_bytes = sum(v["bytes"]   for v in proto_map.values())
        total_blk   = sum(v["blocked"] for v in proto_map.values())

        print(f"\n  {BOLD}Switch: {C}{dpid}{RST}")
        print(f"  Total packets: {W}{total_pkts:,}{RST}  "
              f"Total bytes: {W}{bytes_human(total_bytes)}{RST}  "
              f"Blocked: {R}{total_blk:,}{RST}")
        print()

        hdr = (f"  {'Protocol':<8} {'Packets':>9} {'Bytes':>10} "
               f"{'Flows':>6} {'Blocked':>8}  Traffic Distribution")
        print(DIM + hdr + RST)
        print(DIM + "  " + "─" * 70 + RST)

        for proto in ["TCP", "UDP", "ICMP", "ARP", "OTHER"]:
            s   = proto_map.get(proto, {})
            pkts= s.get("packets", 0)
            byt = s.get("bytes",   0)
            fls = s.get("flows",   0)
            blk = s.get("blocked", 0)
            frac= pkts / total_pkts if total_pkts else 0
            col = PROTO_COLOURS.get(proto, DIM)
            pct = frac * 100

            b = bar(frac, BAR_WIDTH, col)
            print(f"  {col}{proto:<8}{RST} "
                  f"{pkts:>9,} "
                  f"{bytes_human(byt):>10} "
                  f"{fls:>6} "
                  f"{R if blk else DIM}{blk:>8}{RST}  "
                  f"{b} {pct:5.1f}%")

    print()
    print(sep)

    # Traffic distribution pie summary (ASCII)
    print(f"\n  {BOLD}Traffic Distribution Summary{RST}")
    # aggregate across all switches
    agg: dict[str, int] = {}
    for proto_map in switches.values():
        for proto, s in proto_map.items():
            agg[proto] = agg.get(proto, 0) + s.get("packets", 0)
    total_all = sum(agg.values()) or 1

    for proto in ["TCP", "UDP", "ICMP", "ARP", "OTHER"]:
        frac = agg.get(proto, 0) / total_all
        col  = PROTO_COLOURS.get(proto, DIM)
        b    = bar(frac, 40, col)
        print(f"  {col}{proto:<6}{RST} {b}  {frac*100:5.1f}%  "
              f"({agg.get(proto,0):,} pkts)")

    print()


# ── Entry-point ───────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Traffic Classification Stats Viewer")
    ap.add_argument("--file",     default=STATS_FILE, help="Path to stats JSON file")
    ap.add_argument("--interval", type=float, default=3.0, help="Refresh interval (s)")
    ap.add_argument("--once",     action="store_true",    help="Print once and exit")
    args = ap.parse_args()

    if args.once:
        data = load_stats(args.file)
        if data:
            render(data)
        else:
            print(f"Stats file not found: {args.file}")
        return

    print(f"Watching {args.file}  (Ctrl+C to quit)\n")
    try:
        while True:
            data = load_stats(args.file)
            clear()
            if data:
                render(data)
            else:
                ts = datetime.now().strftime("%H:%M:%S")
                print(f"\n[{ts}] Waiting for controller stats file at:\n  {args.file}\n")
                print("Make sure the POX controller is running.\n")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nExiting stats viewer.")


if __name__ == "__main__":
    main()
