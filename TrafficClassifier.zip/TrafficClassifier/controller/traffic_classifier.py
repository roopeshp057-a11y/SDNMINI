"""
traffic_classifier.py  ─  SDN Traffic Classification Controller (POX)
======================================================================
Assignment: Traffic Classification System using Mininet + POX/OpenFlow

Features
────────
  • Classifies every packet as TCP / UDP / ICMP / ARP / OTHER
  • Installs per-protocol OpenFlow match+action rules proactively
  • Handles packet_in events for unmatched / new flows
  • Maintains per-switch, per-protocol statistics
    (packet count, byte count, flow count)
  • Enforces a configurable BLOCK list (protocol or port level)
  • Exposes a real-time ASCII dashboard via POX's timer
  • Writes a JSON stats file every STATS_DUMP_INTERVAL seconds
    → used by the companion display script

Run
───
  cd pox
  ./pox.py log.level --INFO \
           openflow.of_01 --port=6633 \
           traffic_classifier.traffic_classifier \
           --block_udp=False --block_icmp=False --stats_interval=10

OpenFlow Match+Action summary
──────────────────────────────
  Protocol   Priority  Match                     Action
  ─────────────────────────────────────────────────────
  ICMP       300       eth_type=0x0800 ip_proto=1  OUTPUT FLOOD (or DROP if blocked)
  TCP        200       eth_type=0x0800 ip_proto=6  OUTPUT NORMAL
  UDP        200       eth_type=0x0800 ip_proto=17 OUTPUT NORMAL (or DROP if blocked)
  ARP        400       eth_type=0x0806             OUTPUT FLOOD
  Default    10        *                           CONTROLLER (packet_in)
"""

import json
import os
import time
from collections import defaultdict

from pox.core import core
from pox.lib.revent import EventMixin
from pox.lib.util import dpid_to_str
from pox.lib.recoco import Timer
import pox.openflow.libopenflow_01 as of
from pox.lib.packet.ethernet import ethernet
from pox.lib.packet.ipv4 import ipv4
from pox.lib.packet.icmp import icmp
from pox.lib.packet.tcp import tcp
from pox.lib.packet.udp import udp
from pox.lib.packet.arp import arp

log = core.getLogger()

# ── Configuration ────────────────────────────────────────────────────────────
STATS_DUMP_INTERVAL   = 10          # seconds between JSON stats dumps
DASHBOARD_INTERVAL    = 5           # seconds between console dashboard prints
FLOW_IDLE_TIMEOUT     = 30          # OF idle timeout for installed flows
FLOW_HARD_TIMEOUT     = 120         # OF hard timeout for installed flows
STATS_FILE            = os.path.join(os.path.dirname(__file__), "traffic_stats.json")

# Protocol numbers
IP_PROTO_ICMP = 1
IP_PROTO_TCP  = 6
IP_PROTO_UDP  = 17
ETH_TYPE_IP   = 0x0800
ETH_TYPE_ARP  = 0x0806

# Flow priorities (higher = more specific = evaluated first)
PRIO_ARP     = 400
PRIO_ICMP    = 300
PRIO_TCP     = 200
PRIO_UDP     = 200
PRIO_DEFAULT = 10


# ── Statistics container ──────────────────────────────────────────────────────

class ProtoStats:
    """Tracks packet / byte / flow counts for one protocol on one switch."""

    def __init__(self, label: str):
        self.label        = label
        self.packets      = 0
        self.bytes        = 0
        self.flows        = 0
        self.blocked      = 0
        self.last_updated = time.time()

    def record(self, pkt_len: int, blocked: bool = False):
        self.packets      += 1
        self.bytes        += pkt_len
        self.last_updated  = time.time()
        if blocked:
            self.blocked  += 1

    def to_dict(self) -> dict:
        return {
            "label":        self.label,
            "packets":      self.packets,
            "bytes":        self.bytes,
            "flows":        self.flows,
            "blocked":      self.blocked,
            "last_updated": self.last_updated,
        }

    def pct_of(self, total_pkts: int) -> float:
        if total_pkts == 0:
            return 0.0
        return round(100.0 * self.packets / total_pkts, 1)


# ── Per-switch classifier ─────────────────────────────────────────────────────

class SwitchClassifier(EventMixin):
    """
    Attached to one switch connection.
    Proactively installs classification rules and handles packet_in
    events for any traffic that reaches the controller.
    """

    def __init__(self, connection, block_udp: bool, block_icmp: bool,
                 blocked_tcp_ports: set, blocked_udp_ports: set):
        self.connection       = connection
        self.dpid             = connection.dpid
        self.dpid_str         = dpid_to_str(connection.dpid)
        self.block_udp        = block_udp
        self.block_icmp       = block_icmp
        self.blocked_tcp_ports= blocked_tcp_ports
        self.blocked_udp_ports= blocked_udp_ports

        # mac_to_port learning table
        self.mac_to_port: dict = {}

        # Per-protocol stats for this switch
        self.stats = {
            "TCP":   ProtoStats("TCP"),
            "UDP":   ProtoStats("UDP"),
            "ICMP":  ProtoStats("ICMP"),
            "ARP":   ProtoStats("ARP"),
            "OTHER": ProtoStats("OTHER"),
        }

        self.listenTo(connection)
        self._install_proactive_rules()
        log.info("SwitchClassifier ready on %s", self.dpid_str)

    # ── Proactive rule installation ───────────────────────────────────

    def _install_proactive_rules(self):
        """
        Push wildcard classification rules so the switch can act on
        most traffic without sending every packet to the controller.
        A low-priority TABLE-MISS rule still sends unknown frames up.
        """
        self._install_arp_rule()
        self._install_icmp_rule()
        self._install_tcp_rule()
        self._install_udp_rule()
        self._install_table_miss()
        log.info("[%s] Proactive classification rules installed", self.dpid_str)

    def _flow_mod_base(self, priority: int) -> of.ofp_flow_mod:
        msg              = of.ofp_flow_mod()
        msg.priority     = priority
        msg.idle_timeout = FLOW_IDLE_TIMEOUT
        msg.hard_timeout = FLOW_HARD_TIMEOUT
        msg.flags        = of.OFPFF_SEND_FLOW_REM   # notify on expiry
        return msg

    def _install_arp_rule(self):
        msg            = self._flow_mod_base(PRIO_ARP)
        msg.match      = of.ofp_match(dl_type=ETH_TYPE_ARP)
        msg.actions.append(of.ofp_action_output(port=of.OFPP_FLOOD))
        self.connection.send(msg)
        self.stats["ARP"].flows += 1
        log.debug("[%s] Rule: ARP → FLOOD", self.dpid_str)

    def _install_icmp_rule(self):
        msg            = self._flow_mod_base(PRIO_ICMP)
        msg.match      = of.ofp_match(dl_type=ETH_TYPE_IP, nw_proto=IP_PROTO_ICMP)
        if self.block_icmp:
            pass   # empty actions = DROP
            log.info("[%s] Rule: ICMP → DROP (blocked)", self.dpid_str)
        else:
            msg.actions.append(of.ofp_action_output(port=of.OFPP_FLOOD))
            log.debug("[%s] Rule: ICMP → FLOOD", self.dpid_str)
        self.connection.send(msg)
        self.stats["ICMP"].flows += 1

    def _install_tcp_rule(self):
        msg            = self._flow_mod_base(PRIO_TCP)
        msg.match      = of.ofp_match(dl_type=ETH_TYPE_IP, nw_proto=IP_PROTO_TCP)
        # Generic TCP allow; port-level blocking is reactive (packet_in)
        msg.actions.append(of.ofp_action_output(port=of.OFPP_NORMAL))
        self.connection.send(msg)
        self.stats["TCP"].flows += 1
        log.debug("[%s] Rule: TCP → NORMAL", self.dpid_str)

    def _install_udp_rule(self):
        msg            = self._flow_mod_base(PRIO_UDP)
        msg.match      = of.ofp_match(dl_type=ETH_TYPE_IP, nw_proto=IP_PROTO_UDP)
        if self.block_udp:
            pass   # DROP
            log.info("[%s] Rule: UDP → DROP (blocked)", self.dpid_str)
        else:
            msg.actions.append(of.ofp_action_output(port=of.OFPP_NORMAL))
        self.connection.send(msg)
        self.stats["UDP"].flows += 1
        log.debug("[%s] Rule: UDP → NORMAL", self.dpid_str)

    def _install_table_miss(self):
        """Low-priority catch-all: send to controller so we can classify OTHER."""
        msg            = of.ofp_flow_mod()
        msg.priority   = PRIO_DEFAULT
        msg.match      = of.ofp_match()           # wildcard everything
        msg.idle_timeout = 0
        msg.hard_timeout = 0
        msg.actions.append(of.ofp_action_output(port=of.OFPP_CONTROLLER))
        self.connection.send(msg)
        log.debug("[%s] Rule: DEFAULT → CONTROLLER", self.dpid_str)

    # ── Port-specific block rule ─────────────────────────────────────

    def _install_port_block(self, nw_proto: int, tp_dst: int):
        """Install a DROP rule for a specific transport port (higher prio than generic rule)."""
        msg            = self._flow_mod_base(max(PRIO_TCP, PRIO_UDP) + 50)
        msg.match      = of.ofp_match(dl_type=ETH_TYPE_IP,
                                      nw_proto=nw_proto,
                                      tp_dst=tp_dst)
        # No actions = DROP
        self.connection.send(msg)
        proto_name = "TCP" if nw_proto == IP_PROTO_TCP else "UDP"
        log.info("[%s] Port-block rule: %s dst_port=%d → DROP",
                 self.dpid_str, proto_name, tp_dst)

    # ── Packet-In handler ────────────────────────────────────────────

    def _handle_PacketIn(self, event):
        pkt     = event.parsed
        if not pkt.parsed:
            return

        in_port = event.port
        pkt_len = len(event.data)

        # ── MAC learning ──────────────────────────────────────────────
        self.mac_to_port[pkt.src] = in_port

        # ── Classify ─────────────────────────────────────────────────
        proto, blocked, out_port = self._classify(pkt, in_port, pkt_len)

        # ── Record stats ─────────────────────────────────────────────
        self.stats[proto].record(pkt_len, blocked=blocked)

        # ── Log ──────────────────────────────────────────────────────
        log.debug("[%s] packet_in  proto=%-5s blocked=%s  in_port=%d  "
                  "src=%s dst=%s  len=%d",
                  self.dpid_str, proto, blocked, in_port,
                  pkt.src, pkt.dst, pkt_len)

        # ── Forward or drop ──────────────────────────────────────────
        if blocked:
            self._send_drop(event)
        else:
            self._send_packet(event, out_port)

    def _classify(self, pkt, in_port: int, pkt_len: int):
        """
        Classify packet into a protocol category.
        Returns (proto_label, is_blocked, out_port).
        """
        blocked  = False
        out_port = self._resolve_port(pkt.dst)

        if pkt.type == ETH_TYPE_ARP:
            return "ARP", False, of.OFPP_FLOOD

        if pkt.type == ETH_TYPE_IP:
            ip_pkt = pkt.payload
            if not isinstance(ip_pkt, ipv4):
                return "OTHER", False, out_port

            proto = ip_pkt.protocol

            if proto == IP_PROTO_ICMP:
                blocked = self.block_icmp
                return "ICMP", blocked, of.OFPP_FLOOD if not blocked else None

            if proto == IP_PROTO_TCP:
                tcp_pkt = ip_pkt.payload
                if isinstance(tcp_pkt, tcp):
                    if tcp_pkt.dstport in self.blocked_tcp_ports:
                        blocked = True
                        self._install_port_block(IP_PROTO_TCP, tcp_pkt.dstport)
                return "TCP", blocked, out_port

            if proto == IP_PROTO_UDP:
                if self.block_udp:
                    return "UDP", True, None
                udp_pkt = ip_pkt.payload
                if isinstance(udp_pkt, udp):
                    if udp_pkt.dstport in self.blocked_udp_ports:
                        blocked = True
                        self._install_port_block(IP_PROTO_UDP, udp_pkt.dstport)
                return "UDP", blocked, out_port

        return "OTHER", False, out_port

    def _resolve_port(self, dst_mac):
        """Look up output port from MAC table; flood if unknown."""
        entry = self.mac_to_port.get(dst_mac)
        return entry if entry is not None else of.OFPP_FLOOD

    def _send_drop(self, event):
        if event.ofp.buffer_id is not None:
            msg           = of.ofp_packet_out()
            msg.buffer_id = event.ofp.buffer_id
            msg.in_port   = event.port
            # no actions → drop
            self.connection.send(msg)

    def _send_packet(self, event, out_port):
        msg            = of.ofp_packet_out()
        msg.data       = event.ofp
        msg.in_port    = event.port
        msg.actions.append(of.ofp_action_output(port=out_port))
        self.connection.send(msg)

    # ── Flow-removed notification ────────────────────────────────────

    def _handle_FlowRemoved(self, event):
        """Update byte/packet counts from expired flow stats."""
        f = event.ofp
        log.debug("[%s] Flow removed  match=%s  pkts=%d  bytes=%d",
                  self.dpid_str, f.match, f.packet_count, f.byte_count)

    # ── Public stat accessor ─────────────────────────────────────────

    def get_stats_dict(self) -> dict:
        return {proto: s.to_dict() for proto, s in self.stats.items()}

    def total_packets(self) -> int:
        return sum(s.packets for s in self.stats.values())


# ── Top-level POX component ───────────────────────────────────────────────────

class TrafficClassifier(EventMixin):
    """
    Main POX component.
    Creates a SwitchClassifier for every connected switch and
    periodically dumps statistics.
    """

    def __init__(self, block_udp: bool, block_icmp: bool,
                 blocked_tcp_ports: set, blocked_udp_ports: set):
        self.block_udp         = block_udp
        self.block_icmp        = block_icmp
        self.blocked_tcp_ports = blocked_tcp_ports
        self.blocked_udp_ports = blocked_udp_ports

        self.classifiers: dict = {}   # dpid → SwitchClassifier
        self.start_time        = time.time()

        self.listenTo(core.openflow)
        Timer(STATS_DUMP_INTERVAL,   self._dump_stats,      recurring=True)
        Timer(DASHBOARD_INTERVAL,    self._print_dashboard, recurring=True)

        log.info("TrafficClassifier started")
        log.info("  block_udp=%s  block_icmp=%s", block_udp, block_icmp)
        log.info("  blocked_tcp_ports=%s", blocked_tcp_ports or "none")
        log.info("  blocked_udp_ports=%s", blocked_udp_ports or "none")

    # ── Connection events ─────────────────────────────────────────────

    def _handle_ConnectionUp(self, event):
        sc = SwitchClassifier(
            event.connection,
            self.block_udp,
            self.block_icmp,
            self.blocked_tcp_ports,
            self.blocked_udp_ports,
        )
        self.classifiers[event.dpid] = sc
        log.info("Switch UP:  %s", dpid_to_str(event.dpid))

    def _handle_ConnectionDown(self, event):
        self.classifiers.pop(event.dpid, None)
        log.info("Switch DOWN: %s", dpid_to_str(event.dpid))

    # ── Dashboard ─────────────────────────────────────────────────────

    def _print_dashboard(self):
        elapsed = int(time.time() - self.start_time)
        hh, mm  = divmod(elapsed // 60, 60)
        ss      = elapsed % 60
        sep     = "─" * 68

        print(f"\n{sep}")
        print(f"  SDN TRAFFIC CLASSIFICATION DASHBOARD    "
              f"uptime {hh:02d}:{mm:02d}:{ss:02d}")
        print(sep)

        if not self.classifiers:
            print("  (no switches connected)")
            print(sep)
            return

        for dpid, sc in self.classifiers.items():
            total = sc.total_packets()
            print(f"\n  Switch: {sc.dpid_str}")
            print(f"  {'Protocol':<10} {'Packets':>8} {'Bytes':>12} "
                  f"{'%Total':>8} {'Blocked':>8} {'Flows':>6}")
            print(f"  {'─'*10} {'─'*8} {'─'*12} {'─'*8} {'─'*8} {'─'*6}")

            for proto in ["TCP", "UDP", "ICMP", "ARP", "OTHER"]:
                s = sc.stats[proto]
                pct = s.pct_of(total)
                bar = "█" * int(pct / 5)   # tiny bar (max 20 chars)
                blocked_flag = " [BLOCKED]" if (
                    (proto == "UDP"  and self.block_udp) or
                    (proto == "ICMP" and self.block_icmp)
                ) else ""
                print(f"  {proto:<10} {s.packets:>8,} {s.bytes:>12,} "
                      f"{pct:>7.1f}% {s.blocked:>8,} {s.flows:>6}"
                      f"  {bar}{blocked_flag}")

            print(f"\n  Total packets seen: {total:,}")

        print(f"\n{sep}")

    # ── JSON stats dump ───────────────────────────────────────────────

    def _dump_stats(self):
        output = {
            "timestamp":    time.time(),
            "uptime_s":     int(time.time() - self.start_time),
            "config": {
                "block_udp":          self.block_udp,
                "block_icmp":         self.block_icmp,
                "blocked_tcp_ports":  list(self.blocked_tcp_ports),
                "blocked_udp_ports":  list(self.blocked_udp_ports),
            },
            "switches": {},
        }
        for dpid, sc in self.classifiers.items():
            output["switches"][sc.dpid_str] = sc.get_stats_dict()

        try:
            with open(STATS_FILE, "w") as f:
                json.dump(output, f, indent=2)
        except Exception as e:
            log.warning("Could not write stats file: %s", e)

        log.debug("Stats dumped to %s", STATS_FILE)

    def get_global_stats(self) -> dict:
        """Aggregate stats across all switches (for REST API etc.)."""
        agg = defaultdict(lambda: {"packets": 0, "bytes": 0,
                                   "flows": 0, "blocked": 0})
        for sc in self.classifiers.values():
            for proto, s in sc.stats.items():
                agg[proto]["packets"] += s.packets
                agg[proto]["bytes"]   += s.bytes
                agg[proto]["flows"]   += s.flows
                agg[proto]["blocked"] += s.blocked
        return dict(agg)


# ── POX launch entry-point ────────────────────────────────────────────────────

def launch(
    block_udp=False,
    block_icmp=False,
    blocked_tcp_ports="",
    blocked_udp_ports="",
    stats_interval=STATS_DUMP_INTERVAL,
):
    """
    POX launch function.

    Parameters
    ──────────
    block_udp          : True → install DROP rules for all UDP traffic
    block_icmp         : True → install DROP rules for all ICMP traffic
    blocked_tcp_ports  : comma-separated TCP dst ports to block, e.g. "22,23"
    blocked_udp_ports  : comma-separated UDP dst ports to block, e.g. "53,161"
    stats_interval     : seconds between JSON stats file writes
    """
    global STATS_DUMP_INTERVAL
    STATS_DUMP_INTERVAL = int(stats_interval)

    def _parse_ports(s) -> set:
        if not s:
            return set()
        return {int(p.strip()) for p in str(s).split(",") if p.strip().isdigit()}

    tcp_blocked = _parse_ports(blocked_tcp_ports)
    udp_blocked = _parse_ports(blocked_udp_ports)

    from pox.lib.util import str_to_bool
    core.registerNew(
        TrafficClassifier,
        str_to_bool(str(block_udp)),
        str_to_bool(str(block_icmp)),
        tcp_blocked,
        udp_blocked,
    )
